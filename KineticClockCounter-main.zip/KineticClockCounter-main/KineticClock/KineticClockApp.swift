//
//  KineticClockApp.swift
//  KineticClock
//
//  Created by Waseem Akram on 13/03/21.
//

import SwiftUI

@main
struct KineticClockApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView(counterManager: CounterManager())
        }
    }
}
