# Kinetic Clock Counter

### Made with SwiftUI

![app](https://github.com/devwaseem/KineticClockCounter/raw/main/assets/main.gif)

inspired by: 
- [@ezihyilmaz94](https://twitter.com/nezihyilmaz94/status/1368623335530233865) work using jetpack compose
- https://www.youtube.com/watch?v=utK3WYRB_ww
